package by.htp.students;

public class Group {

	private String title;
	private Student[] students;
	private int studentCounter;

	public Group() {
	}

	public Group(String title) {
		this.title = title;
	}

	public void setStudents(Student[] students) {
		if (students != null) {
			this.students = students;
		}
	}

	public Student[] getStudents() {
		return this.students;
	}

	public void setTitle() {
		this.title = title;
	}

	public String getTitle() {
		return this.title;
	}

	public void addStudent(Student student) {
		if (this.students != null) {
			if (studentCounter < students.length) {
				students[studentCounter] = student;
				studentCounter++;
			} else {
				Student[] students = new Student[this.students.length + 1];
				for (int i = 0; i < this.students.length; i++) {
					students[i] = this.students[i];
				}
				this.students = students;
				this.students[studentCounter] = student;
				studentCounter++;
			}
		} else {
			this.students = new Student[2];
			this.students[studentCounter] = student;
			studentCounter++;
		}
	}

	public void avgCount(Student[] students) {
		int ageSum = 0;
		for (int i = 0; i < students.length; i++) {
			ageSum += students[i].age;
		}
		System.out.println((double) (ageSum / students.length));

	}
	
	public void stdCount(Student[] students) { 
		int stdSum = 0; 
		for (int i = 0; i < students.length; i++) { 
		if (2015 == students[i].year) {
			stdSum++;
		}
		} 
		System.out.println(stdSum); 
	}
	
	//public void maxstudyear(Student[] students) { 
		//int my = 0; 
		//for (int i = 0; i < students.length; i++) { 
		//if (students[i].year == ) {
			//my++;
		//}
		//} 
		//System.out.println(my); 
	
           //}
}