package by.htp.students;


public class MainApp {

	public static void main(String[] args) {
		
		Student stud1 = new Student("name",15,2015);
		Student stud2 = new Student("name",17,2011);
		Student stud3 = new Student("name",16,2012);
		Student stud4 = new Student("name",15,2013);
		Student stud5 = new Student("name",18,2015);
		Student stud6 = new Student("name",15,2015);
		
	
		Group gr1 = new Group("Group");
		
		
		Student[] students = new Student[] {stud1, stud2, stud3, stud4, stud5, stud6};
		gr1.setStudents(students);
		System.out.println();
	}

}
